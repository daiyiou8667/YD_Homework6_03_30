# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 13:09:35 2021

@author: genti
"""
#%%====
import pandas as pd
from keras import models, layers
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics, linear_model
#from tkinter import filedialog
import tkinter as tk
import matplotlib.pyplot as plt
root = tk.Tk()
root.withdraw()
#%%===================
#main_dir = filedialog.askdirectory(parent=root,initialdir="//",title='Pick a directory for the project')
main_dir='/Users/ydai/Downloads/EXST7087/Random Forest/YD_Homework_03_30'
Ex1 = pd.read_csv(main_dir+'/Data/data.csv') #index_col=0) #Read a comma-separated values (csv) file into DataFrame
#%%===================
#Ex1.dropna(subset=['VRYieldVOl'],inplace=True) # drop missing values in Ex1 
#Ex2=Ex1[Ex1['VRYieldVOl']>0] #drop negative value, yield should be positive 
#%%====
cols = list(Ex1)
cols.insert(0, cols.pop(cols.index('flower_onset'))) # make sure to put y(output) variable in the beginning 
Ex1=Ex1.loc[:,cols] #loc:select all the rows in the order of cols.
df1=Ex1.describe() #describe the dataset, important result. Every data should have this information 
df1.to_csv(main_dir+'/Results/Data_Description.csv') #important result should be saved without running the code
#%%==== 
#Nancols=Ex1.columns[Ex1.isna().any()] # which column has na value
#Ex1[Nancols]=Ex1[Nancols].fillna(Ex1.mean().iloc[0]) #filling the value with the mean (not adding variance)  (the model doesn't work with na.)
#%%==== 
#Ex3 = pd.get_dummies(Ex1) #turn categorical into numberical yes and no 
#%%==== 
X=Ex1.iloc[:,1:len(Ex1.columns)].values #split into x and y variables 
y=Ex1.iloc[:,0].values.flatten() #requirement for sklearn 
#%%=====Initialzing empty list to save result==== 
rf_errors = [] #initializing  empty list 
regr_errors = []
nn_errors = []
#%%==== 
for i in range(10):
    #
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=True)
    #
    sc = StandardScaler()  # z standardized transformation to make your number smaller, don't gain anything or lose anything. 
    X_train = sc.fit_transform(X_train)  
    X_test = sc.transform(X_test)  

    #
    regressor = RandomForestRegressor(n_estimators=100)  # the # of trees in the forest, In real work don't set random_state
    regressor.fit(X_train, y_train)  #build a forest of trees from training set(x,y)
    RF_pred = regressor.predict(X_test)  #predict regression target for x. 
    #
    a=metrics.mean_squared_error(y_test, RF_pred) #mean square error regression loss
    rf_errors.append(a)
    
    #
    regr = linear_model.LinearRegression() #ordinary least square linear regression 
    regr.fit(X_train, y_train) #fit linear model
    LR_pred=regr.predict(X_test) #predict using  the linear model
    #
    b=metrics.mean_squared_error(y_test, LR_pred) #mean square error regression loss
    regr_errors.append(b)

    # fitting the Neutal Network Model 
    #nn=models.Sequential() #how to initiate the neural network 
    #nn.add(layers.Dense(80, activation='relu', input_shape=[X_train.shape[1]])) # shape 1 means the number of column. adding layers as how much you want 
    #nn.add(layers.Dense(40, activation='relu'))
    #nn.add(layers.Dense(20, activation='relu'))
    #nn.add(layers.Dense(10, activation='relu'))
    #nn.add(layers.Dense(1))
    #nn.fit(X_train, y_train, epochs=10, batch_size=5)
    #NN_pred = nn.predict(X_test) # predicted values from neural network 
    #
    #c=metrics.mean_squared_error(y_test, NN_pred)
    #nn_errors.append(c) #store mse to the empty list 
    
    #print("Finished Itteration",i) 
#%%==== 
Result_errors1=pd.DataFrame({'Random_Forest':rf_errors,"Simple_Regression":regr_errors})
#Result_errors2=Result_errors1[Result_errors1["Simple_Regression"]<600] #deal with outliers 
#Result_errors3=Result_errors2.sample(n=6) #random sample imporove the accuracy in some journal 
Result_errors1.to_csv(main_dir+'/Results/Errors.csv') #save the error to results file
#%%==== 
fig, ax = plt.subplots()
# 
ax.boxplot(Result_errors1)
#ax.boxplot(Result_errors2) #outliers 
# 
ax.set_title('Side by Side Boxplot of RMSE for different Models')
ax.set_xlabel('Predictive Models')
ax.set_ylabel('Root Mean Square Errors')
xticklabels=['Random Forest','Simple Regression']

ax.set_xticklabels(xticklabels)
# 
ax.yaxis.grid(True)
# 
plt.savefig(main_dir+'/Results/Side_by_Side.png')
#%%====
Res=Result_errors1.describe()
Res.to_csv(main_dir+'/Results/Error_description.csv')